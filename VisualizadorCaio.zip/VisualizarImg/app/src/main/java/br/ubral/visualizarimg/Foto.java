package br.ubral.visualizarimg;

public class Foto {
}
